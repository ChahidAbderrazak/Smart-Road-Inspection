#!/bin/bash
# 1- install general packages

# 1- install opencv
pip install numpy
apt list python*opencv*
sudo apt -y install python3-opencv 
 # apt show python3-opencv

# 3- install virtual env
# https://raspberrypi-guide.github.io/programming/create-python-virtual-environment

# 3- install packages
pip install -r requirements.txt 
