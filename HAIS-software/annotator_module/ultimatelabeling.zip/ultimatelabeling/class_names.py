DEFAULT_CLASS_NAMES = {
0: 'road-hole',
1:'road-crack',
}