DEFAULT_CLASS_NAMES = {
0: 'Air_background',
1:'Outer_housing_Assembled_view_part.step',
2:'1_Connection_disk.step',
3:'1_Cotter_Pin.step',
4:'1_inner_cover_bottom.step',
5:'1_inner_cover_top.step',
6:'1_Key_Outer_housing.step',
7:'1_M6_x_23.step',
8:'1_M6_x_30.step',
9:'1_M6_x_40.step',
10:'1_M6_x_60.step',
11:'1_outer_end_connection_for_universal_joint.step',
12:'1_Snap_ring.step',
13:'1_Spring_for_support_part.step',
14:'1_Suppor_part_(inner_disk_clips).step',
15:'1_Support_part_(_spring_stopper).step',
16:'1_Support_part_(spring_holder).step',
17:'1_Support_Part_internal_disk.step',
18:'1_Support_part.step',
19:'1_Universal_Joint_connection_fixture.step',
20:'1_Universal_joint_inner_connection.step',
21:'1_universal_joint_Outer_housing.step',
22:'1_Universal_joint_pin.step'
}

DEFAULT_CLASS_NAMES = {
 0: 'car',
 1: 'truck',
 2: 'bus',
 3: 'van',
 4: 'cyclist',
 5: 'pedestrian'
}
