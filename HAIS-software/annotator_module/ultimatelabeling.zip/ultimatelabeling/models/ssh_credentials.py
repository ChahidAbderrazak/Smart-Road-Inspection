class SSHCredentials:
    def __init__(self, hostname="", username="", password=""):
        self.hostname = hostname
        self.username = username
        self.password = password
