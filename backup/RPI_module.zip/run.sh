#!/bin/bash
cd src

############# Data collection  ################
echo "==> Start the data collection"
python main_data_collection.py

