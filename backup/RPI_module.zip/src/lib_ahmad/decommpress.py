# -*- coding: utf-8 -*-
"""
Created on Wed Sep  7 12:16:01 2022

@author: 100840150
"""

from lib_ahmad.HAIS_project import *
def main1():
    while True:
            decommpress()
    
if __name__ == "__main__":
    main1()




