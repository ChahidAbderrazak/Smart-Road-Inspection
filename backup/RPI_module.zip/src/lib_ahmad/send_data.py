# -*- coding: utf-8 -*-
"""
Created on Sun Jul 24 10:04:01 2022

@author: 100840150
"""

                  




from lib_ahmad.HAIS_project import *

def send():
        while True:
            if os.listdir(root)!=[]:
                send_data()

if __name__ == "__main__":
    send()



