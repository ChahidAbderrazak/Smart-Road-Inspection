# -*- coding: utf-8 -*-
"""
Created on Sun Jul 24 10:12:26 2022

@author: 100840150
"""

from lib_ahmad.HAIS_project import *
def read():
    while True:
        get_data()  
        decommpress()
if __name__ == "__main__":
    read()
    