#  Highway Automated Inspection System (HAIS) node


# install the needed  packages

1. **GPS sensor**
```
$ sudo apt install gpsd
$ sudo apt install gpsd-clients
```
[more details](https://gpswebshop.com/blogs/tech-support-by-os-linux/how-to-connect-an-usb-gps-receiver-with-a-linux-computer)



# Run data collection 
```
$ ./run.sh
```

# Acknowledgement

The proposed method used some other existing preprocessing packages which were adapted with/without modifications. The main ressources are cited as follows:
*  [source1](https://github.com/)
* 